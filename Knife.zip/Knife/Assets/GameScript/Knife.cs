﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Knife : MonoBehaviour
{
    [SerializeField]
    float speed = 0;
    int startMove = 3;
    public bool CanDestroy = false;
    public GameObject partical;

    public void SetKnife(float speed,bool move) {
        this.speed = speed;
        if (move)
            startMove = 0;
        else
            startMove = 3;
    }

    void Start()
    {
        GetComponent<Animator>().speed = 0;
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (startMove == 0)
                startMove = 1;
        }
    }
    void FixedUpdate()
    {

        
        if (startMove == 1)
            transform.position = Vector2.MoveTowards(transform.position, Vector3.up * 5, Time.fixedDeltaTime * speed);
        if(CanDestroy)
            Destroy(gameObject);
    }
    

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (startMove == 1)
        {
            Lvl info = GameObject.FindGameObjectWithTag("Info").GetComponent<Lvl>();
            if (collision.gameObject.tag == "Circle")
            {
                startMove = 3;
                gameObject.transform.position = collision.gameObject.GetComponent<Circle>().knifePos;

                collision.gameObject.GetComponent<Circle>().AddKnife(gameObject);
                info.MinusKnife(false);
                Vibration.Vibrate(100);
                partical.GetComponent<ParticleSystem>().Play();


            }
            else if (collision.gameObject.tag == "Apple")
            {
                info.AddApple();
                Destroy(collision.gameObject);
            }
            else
            {
                
                if (startMove == 1) {
                    startMove = 3;
                    DestroyA();
                    info.MinusKnife(true);
                    Vibration.Vibrate(200);
                }
                    
            }
        }
        
    }

    public void DestroyA() {
        GetComponent<Animator>().speed = 1;
        
    }

}
