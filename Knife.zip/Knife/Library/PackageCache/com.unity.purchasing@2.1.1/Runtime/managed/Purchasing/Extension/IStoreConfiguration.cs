namespace UnityEngine.Purchasing.Extension
{
    /// <summary>
    /// Common interface for all extended configuration.
    /// </summary>
    public interface IStoreConfiguration
    {
    }
}
